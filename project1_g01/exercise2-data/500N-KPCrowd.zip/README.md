# 500N-KPCrowd benchmark dataset

Original dataset can be retreived from this [link](marujo-2012).

[marujo-2012]: https://www.l2f.inesc-id.pt/w/500N-KPCrowd